<h3>hbkjfdsnb</h3>
<?php /**PATH G:\Server-Batch-31\htdocs\Laravel-_Batch-31_LARAVEL\batch-31-crud\resources\views/departments.blade.php ENDPATH**/ ?>