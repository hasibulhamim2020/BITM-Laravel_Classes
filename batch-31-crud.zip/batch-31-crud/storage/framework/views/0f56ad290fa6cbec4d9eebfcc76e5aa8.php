<?php $__env->startSection('title'); ?>
    Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card">
                        <div class="card-header"><h5><b>Student Create Form</b></h5></div>
                        <div class="card-body">
                            <form action="<?php echo e(route('update')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                
                                <input type="hidden" value="<?php echo e($student->id); ?>" name="id">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Student Name</label>
                                    <input value="<?php echo e($student->name); ?>" id="name" type="text" name="name" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label for="department" class="form-label">Student Department</label>
                                    <select id="department" type="text" name="department_id" class="form-control">

                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>" <?php echo e(($department->id == $student->department_id)? 'selected':''); ?>><?php echo e($department->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="session" class="form-label">Student Session</label>
                                    <select id="session" type="text" name="session_id" class="form-control">

                                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($session->id); ?>" <?php echo e(($session->id == $student->session_id)? 'selected':''); ?>><?php echo e($session->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Student Email</label>
                                    <input value="<?php echo e($student->email); ?>" id="email" type="email" name="email" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Student Phone</label>
                                    <input value="<?php echo e($student->phone); ?>" id="phone" type="text" name="phone" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label for="address" class="form-label">Student address</label>
                                    <textarea id="address"  name="address" class="form-control"><?php echo e($student->address); ?></textarea>
                                </div>
                                <div>
                                    <label for="image" class="form-label">Image</label>
                                    <br>
                                    <img src="<?php echo e(asset($student->image)); ?>" style="height: 150px" width="150px" alt="Not found">
                                    <br><br>
                                    <input id="image" type="file" name="image" class="form-control">
                                    <br><br>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit Student Data</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server-Batch-31\htdocs\Laravel-_Batch-31_LARAVEL\batch-31-crud\resources\views/edit.blade.php ENDPATH**/ ?>