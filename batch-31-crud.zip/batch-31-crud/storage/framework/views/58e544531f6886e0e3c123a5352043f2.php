<?php $__env->startSection('title'); ?>
    Create
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card">
                        <div class="card-header"><h5><b>Student Manage Table</b></h5></div>
                        <div class="card-body">
                            <table class="table table-hover table-bordered table-striped">
                                <tr>
                                    <th>Sl.</th>
                                    <th>Session Name</th>
                                    <th>Session code</th>
                                    <th>status</th>
                                    <th>action</th>
                                </tr>
                                <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($session->name); ?></td>
                                        <td><?php echo e($session->code); ?></td>
                                        <td><?php echo e($session->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('sessions.edit',$session->id)); ?>" class="btn btn-primary btn-sm">Edit</a>

                                            <a href="<?php echo e(route('session.wise.student')); ?>" class="btn btn-success btn-sm">session wise student list</a>

                                        <?php if($session-> status == 1): ?>
                                                <a href="<?php echo e(route('sessions.show',$session->id)); ?>" class="btn btn-info btn-sm">Inactive</a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('sessions.show',$session->id)); ?>" class="btn btn-info btn-sm">Active</a>
                                            <?php endif; ?>
                                                <form action="<?php echo e(route('sessions.destroy',$session->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this!!')">Delete</button>
                                                </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server-Batch-31\htdocs\Laravel-_Batch-31_LARAVEL\batch-31-crud\resources\views/session/index.blade.php ENDPATH**/ ?>