<?php $__env->startSection('title'); ?>
    Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card">
                        <div class="card-header"><h5><b>Student Manage Table</b></h5></div>
                        <div class="card-body">
                            <table class="table table-hover table-bordered table-striped">
                                <tr>
                                    <th>Sl.</th>
                                    <th>deparment Name</th>
                                    <th>deparment code</th>
                                    <th>status</th>
                                    <th>action</th>
                                </tr>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($department->name); ?></td>
                                        <td><?php echo e($department->code); ?></td>
                                        <td><?php echo e($department->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('departments.edit',$department->id)); ?>" class="btn btn-primary btn-sm">Edit</a>


                                            <?php if($department-> status == 1): ?>
                                                <a href="<?php echo e(route('departments.show',$department->id)); ?>" class="btn btn-info btn-sm">Inactive</a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('departments.show',$department->id)); ?>" class="btn btn-info btn-sm">Active</a>
                                            <?php endif; ?>


                                                <form action="<?php echo e(route('delete',['id'=>$department->id])); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($department->id); ?>" name="id">
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this!!')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server-Batch-31\htdocs\Laravel-_Batch-31_LARAVEL\batch-31-crud\resources\views/department/index.blade.php ENDPATH**/ ?>