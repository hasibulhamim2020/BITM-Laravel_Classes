<?php $__env->startSection('title'); ?>
    Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card">
                        <div class="card-header"><h5><b>Session Edit Form</b></h5></div>
                        <div class="card-body">
                            <form action="<?php echo e(route('sessions.update',$session->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="mb-3">
                                    <label for="name" class="form-label">Session Name</label>
                                    <input value="<?php echo e($session->name); ?>" id="name" type="text" name="name" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label for="code" class="form-label">Session code</label>
                                    <input value="<?php echo e($session->code); ?>" id="code" type="code" name="code" class="form-control">
                                </div>
                                <button type="submit" class="btn btn-primary">Submit Session Data</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server-Batch-31\htdocs\Laravel-_Batch-31_LARAVEL\batch-31-crud\resources\views/session/edit.blade.php ENDPATH**/ ?>