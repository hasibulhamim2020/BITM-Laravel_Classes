<script src="<?php echo e(asset('assets')); ?>/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH E:\PHP-BITM-SERVER\htdocs\Laravel-BITM\hamim-332922\resources\views/footer.blade.php ENDPATH**/ ?>