<script src="{{asset('assets')}}/js/bootstrap.bundle.min.js"></script>
</body>
</html>
