<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SudentController;
use App\Http\Controllers\DepartmentController;


Route::get('/',[HomeController::class,'index'])->name('home');
Route::get('/add/student',[SudentController::class,'addStudent'])->name('add-student');
Route::get('/manage/student',[SudentController::class,'manageStudent'])->name('manage-student');
Route::post('/store',[SudentController::class,'store'])->name('store');
Route::post('/update',[SudentController::class,'update'])->name('update');
//Route::get('/delete/student/{id}',[SudentController::class,'deleteinfo'])->name('delete');
Route::post('/delete/student',[SudentController::class,'deleteinfo'])->name('delete');
Route::get('/edit/student/{id}',[SudentController::class,'edit'])->name('edit');


Route::resources(['departments' => DepartmentController::class]);
